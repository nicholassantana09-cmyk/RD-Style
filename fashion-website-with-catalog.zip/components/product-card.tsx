"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import Image from "next/image"

interface ProductCardProps {
  product: {
    id: number
    name: string
    price: number
    sizes: string[]
    image: string
    category: string
  }
}

export function ProductCard({ product }: ProductCardProps) {
  return (
    <Card className="group overflow-hidden border-border bg-card hover:border-muted-foreground/30 transition-all duration-300">
      <div className="relative aspect-square overflow-hidden bg-secondary">
        <Image
          src={product.image || "/placeholder.svg"}
          alt={product.name}
          fill
          className="object-cover transition-transform duration-500 group-hover:scale-110"
        />
      </div>
      <CardContent className="p-4 space-y-2">
        <div className="flex items-start justify-between gap-2">
          <h3 className="font-sans text-lg font-semibold text-foreground line-clamp-1">{product.name}</h3>
          <Badge variant="secondary" className="bg-accent text-accent-foreground shrink-0">
            {product.category}
          </Badge>
        </div>
        <p className="text-2xl font-bold text-primary">R$ {product.price.toFixed(2)}</p>
        <div className="flex flex-wrap gap-2 pt-1">
          {product.sizes.map((size) => (
            <Badge key={size} variant="outline" className="border-border text-muted-foreground">
              {size}
            </Badge>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
